<!DOCTYPE html>

<html lang="en">

    <head>

        <?php include('php/meta.php'); ?>

        <title>Template Page</title>

        <?php include('php/stylesheet.php'); ?>

    </head>

    <body>

        <?php include('php/header.php'); ?>

        <?php include('php/about-us.php'); ?>

        <?php include('php/portfolio.php'); ?>

        <?php include('php/service.php'); ?>

        <!--content here-->

        <?php include('php/contact_section.php'); ?>
        
        <?php include('php/footer.php'); ?>

        <?php include('php/scripts.php'); ?>

    </body>
