  <!-- contact section -->
  <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user inputs from the form
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $message = $_POST["message"];

    // Validate the data (you can add more validation here)
    if (empty($name) || empty($email) || empty($phone) || empty($message)) {
        // Handle validation errors, e.g., redirect back to the form with an error message
        header("Location: contact.php?error=fields");
        exit();
    }

    // Send an email 
    $to = "rahulgoswami9072001@email.com";
    $subject = "Contact Form Submission from $name";
    $messageBody = "Name: $name\nEmail: $email\nPhone: $phone\nMessage:\n$message";

    if (mail($to, $subject, $messageBody)) {
        // Email sent successfully
        header("Location: thank-you.html"); // Redirect to a thank you page
        exit();
    } else {
        // Email not sent, handle the error
        header("Location: contact.php?error=email");
        exit();
    }
} else {
    // Handle the case where the form was not submitted properly
    header("Location: contact.php");
    exit();
}
?>


  <!-- end contact section -->