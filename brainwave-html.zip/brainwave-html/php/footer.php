 <!-- info section -->
 <section class="info_section layout_padding-top layout_padding2-bottom">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-lg-3">
          <div class="info_links pl-lg-5">
            <h4>
              Menu
            </h4>
            <ul>
              <li class="active">
                <a href="index.html">
                  Home
                </a>
              </li>
              <li>
                <a href="about.html">
                  About
                </a>
              </li>
              <li>
                <a class="" href="portfolio.html">Portfolio </a>
              </li>
              <li>
                <a class="" href="service.html">Services</a>
              </li>
              <li>
                <a href="contact.html">
                  Contact Us
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="info_contact">
            <h4>
              Location
             
            </h4>
            <div>
              <img src="images/location.png" alt="" />              
                Bhopal,Madhya pradesh,462007
            </div>
            <div>
              <style></style>
              <img src="images/envelope.png" alt="" />
              
                rahulgoswami9072001@gmail.com
              
            </div>
          </div>
        </div>
 <!-- info section -->
 <section class="info_section layout_padding-top layout_padding2-bottom">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-lg-4">
          <div class="info_contact">
            <h4>
              Location
             
            </h4>
            <div>
              <img src="images/location.png" alt="" />              
                Bhopal,Madhya pradesh,462007
            </div>
         =
          </div>
        </div>

        <div class="col-md-6 col-lg-4">
          
          <div class="info_social">
            <h4>
              Social Link
            </h4>
            <div class="social_container">
              <div>
                <a href="https://www.facebook.com/avinav.sinha.982" class="fa fa-facebook">
                </a>
              </div>
             
              <div>
                <a href="https://instagram.com/avinav2626?utm_source=qr&igshid=MThlNWY1MzQwNA==" class ="fa fa-instagram"> 
                </a>
              </div>
              <div>
                <a href="https://www.linkedin.com/in/avinav-sinha-40731a1aa?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" class = "fa fa-linkedin">
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="info_form">
            <h4>
              Newsletter
            </h4>
            <form action="#">
              <input type="text" placeholder="Enter Your Email" />
              <button type="submit">
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end info_section -->